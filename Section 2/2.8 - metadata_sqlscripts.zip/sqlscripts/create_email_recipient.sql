CREATE TABLE dbo.EmailRecipients (
    FirstName varchar(100) null,
    LastName varchar(100) null,
    EmailAddress varchar(100) null
)
GO
